#Magisk modules use $MODPATH as main path
#Your script starts here:
system_build="/system/build.prop"
module="$MODPATH/module.prop"
android=$(get_file_prop $system_build ro.build.version.release)
manufacturer=$(get_file_prop $system_build ro.product.system.manufacturer)
model=$(file_getprop $system_build ro.product.system.model)
security_patch=$(file_getprop $system_build ro.build.version.security_patch)
myid=$(file_getprop $system_build ro.build.display.id)
#Print

fprint "$addons/xuanhoa.txt"
ui_print " |--| Install on device: $model               |--| "
ui_print " |--| Version: $myid |--| "
ui_print " |--| Security Patch: $security_patch                |--| "
ui_print " |--|-------------------------------------------|--| "
ui_print " "
if exist $module; then
   replace "version=" "version=S24 Wallpaper" $module
   replace "name=" "name=VN-ROM mod for the $model" $module
else
   abort "CANT FIND: module.prop"
fi
ui_print " "

#Install
ui_print " -- Installing..."
if exist /system/etc/floating_feature.xml; then
   copy /system/etc/floating_feature.xml "$MODPATH/system/etc/floating_feature.xml"
   replace "    <SEC_FLOATING_FEATURE_LOCKSCREEN_CONFIG_WALLPAPER_STYLE>" "    <SEC_FLOATING_FEATURE_LOCKSCREEN_CONFIG_WALLPAPER_STYLE>GENWEATHER,FLIPSUIT_LOCK," $MODPATH/system/etc/floating_feature.xml
   replace "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_BRIGHTNESS_ANIMATION>0" "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_BRIGHTNESS_ANIMATION>1" $MODPATH/system/etc/floating_feature.xml
   replace "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>0" "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>1" $MODPATH/system/etc/floating_feature.xml
   force_update_file_addon floating.txt "$MODPATH/system/etc/floating_feature.xml"

   copy /system/vendor/etc/floating_feature.xml "$MODPATH/system/vendor/etc/floating_feature.xml"
   replace "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_BRIGHTNESS_ANIMATION>0" "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_BRIGHTNESS_ANIMATION>1" $MODPATH/system/vendor/etc/floating_feature.xml
   replace "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>0" "    <SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>1" $MODPATH/system/vendor/etc/floating_feature.xml
   force_update_file_addon vendorfl.txt "$MODPATH/system/vendor/etc/floating_feature.xml"
else
   abort "CANT FIND: floating_feature.xml"
fi
try_mount -rw /optics
vnmod1=/optics/configs/carriers
find $vnmod1 -type f -name "cscfeature.xml" -exec sed -i -- '/CscFeature_Common_SupportZProjectFunctionInGlobal/d' {} + 
find $vnmod1 -type f -name "cscfeature.xml" -exec sed -i -- '/<FeatureSet>/ a\    <CscFeature_Common_SupportZProjectFunctionInGlobal>TRUE</CscFeature_Common_SupportZProjectFunctionInGlobal>' {} +

package_extract_dir VNROM/system "$MODPATH/system"
package_extract_dir VNROM/system_ext "$MODPATH/system/system_ext"
#Set contexts
set_context /system "$MODPATH/system"

ui_print " "
ui_print " |--|-------------------------------------------|--| "
ui_print " |--| Installation successful!                  |--| "
ui_print " |--| Reboot and enjoy.. VN-ROM                 |--| "
ui_print " |--|-------------------------------------------|--| "
ui_print " "