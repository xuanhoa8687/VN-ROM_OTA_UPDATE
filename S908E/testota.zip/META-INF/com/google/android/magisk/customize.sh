#Magisk modules use $MODPATH as main path
#Your script starts here:
system_build="/system/build.prop"
module="$MODPATH/module.prop"
android=$(get_file_prop $system_build ro.build.version.release)
manufacturer=$(get_file_prop $system_build ro.product.system.manufacturer)
model=$(file_getprop $system_build ro.product.system.model)
security_patch=$(file_getprop $system_build ro.build.version.security_patch)
myid=$(file_getprop $system_build ro.build.display.id)
#Print

fprint "$addons/xuanhoa.txt"
ui_print " |--| Install on device: $model               |--| "
ui_print " |--| Version: $myid |--| "
ui_print " |--| Security Patch: $security_patch                |--| "
ui_print " |--|-------------------------------------------|--| "
ui_print " "
if exist $module; then
   replace "version=" "version=$myid" $module
   replace "name=" "name=VN-ROM mod for the $model" $module
else
   abort "CANT FIND: module.prop"
fi

try_mount -rw /optics /prism /sec_efs
csc_code=`cat /prism/etc/code`
csc_imei=`cat /sec_efs/imei/mps_code.dat`
single=/optics/configs/carriers/single/$csc_imei/conf/system/cscfeature.xml
carriers=/optics/configs/carriers/$csc_imei/conf/system/cscfeature.xml




	

if [[ -d "/optics/configs/carriers/$csc_imei" ]]; then
	replace "    <CscFeature_Common_SupportZProjectFunctionInGlobal>FALSE</CscFeature_Common_SupportZProjectFunctionInGlobal>" "    <CscFeature_Common_SupportZProjectFunctionInGlobal>TRUE</CscFeature_Common_SupportZProjectFunctionInGlobal>" $carriers
	ui_print " FIND: $carriers"
else
	replace "    <CscFeature_Common_SupportZProjectFunctionInGlobal>FALSE</CscFeature_Common_SupportZProjectFunctionInGlobal>" "    <CscFeature_Common_SupportZProjectFunctionInGlobal>TRUE</CscFeature_Common_SupportZProjectFunctionInGlobal>" $single
	ui_print " FIND: $single"
fi
#Install
ui_print " -- Installing..."
package_extract_dir VNROM/system "$MODPATH/system"
package_extract_dir VNROM/system_ext "$MODPATH/system/system_ext"
#Set contexts
set_context /system "$MODPATH/system"

ui_print " "
ui_print " |--|-------------------------------------------|--| "
ui_print " |--| Installation successful!                  |--| "
ui_print " |--| Reboot and enjoy.. VN-ROM                 |--| "
ui_print " |--|-------------------------------------------|--| "
ui_print " "